import { useState, useEffect, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Mail, MessageSquare, Zap, Play, Image as ImageIcon, Send, CreditCard, ExternalLink, Users, Volume2, VolumeX } from "lucide-react";
import { toast } from "sonner";

export default function Home() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [mousePos, setMousePos] = useState({ x: 0, y: 0 });
  const [isMuted, setIsMuted] = useState(false);
  const audioRef = useRef<HTMLAudioElement>(null);
  const cardRef = useRef<HTMLDivElement>(null);

  // Enhanced mouse parallax effect - faster and smoother
  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      const x = (e.clientX / window.innerWidth) * 40 - 20;
      const y = (e.clientY / window.innerHeight) * 40 - 20;
      setMousePos({ x, y });
    };

    window.addEventListener("mousemove", handleMouseMove);
    return () => window.removeEventListener("mousemove", handleMouseMove);
  }, []);

  // Auto-play background music
  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.volume = 0.3;
      audioRef.current.play().catch(() => {
        // Browser might block autoplay, that's ok
      });
    }
  }, []);

  const toggleMute = () => {
    if (audioRef.current) {
      if (isMuted) {
        audioRef.current.play();
        setIsMuted(false);
        toast.success("الصوت مفعل");
      } else {
        audioRef.current.pause();
        setIsMuted(true);
        toast.success("الصوت مغلق");
      }
    }
  };

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (email && password) {
      setIsLoggedIn(true);
      setEmail("");
      setPassword("");
      toast.success("تم تسجيل الدخول بنجاح!");
    }
  };

  const handleLogout = () => {
    setIsLoggedIn(false);
    toast.success("تم تسجيل الخروج");
  };

  const handleSubscribe = (plan: string) => {
    window.open("https://wa.me/905526558548?text=مرحبا%20اريد%20الاشتراك%20في%20VST%20Cheats", "_blank");
  };

  const handleContact = () => {
    window.open("https://guns.lol/br4zil7", "_blank");
  };

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  if (!isLoggedIn) {
    return (
      <div className="min-h-screen bg-background text-foreground flex items-center justify-center px-4 scanline relative overflow-hidden">
        {/* Background Music */}
        <audio
          ref={audioRef}
          src="https://d2xsxph8kpxj0f.cloudfront.net/310419663031979111/Fs5wiWQggZNfgF3JSoAX3t/TIKITIKI(Slowed)[EXTENDED]_a21d108f.mp3"
          loop
          playsInline
        />

        {/* Network Particles */}
        <div className="network-particles">
          <div className="particle"></div>
          <div className="particle"></div>
          <div className="particle"></div>
          <div className="particle"></div>
          <div className="particle"></div>
          <div className="particle"></div>
          <div className="particle"></div>
          <div className="particle"></div>
        </div>

        {/* Spider Web Animation */}
        <div className="spider-web">
          <div className="spider-web-line"></div>
          <div className="spider-web-line"></div>
          <div className="spider-web-line"></div>
          <div className="spider-web-line"></div>
          <div className="spider-web-line"></div>
        </div>

        {/* Background decoration */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <div className="absolute top-0 left-0 w-96 h-96 bg-gradient-to-br from-[#ff0055]/10 to-transparent rounded-full blur-3xl"></div>
          <div className="absolute bottom-0 right-0 w-96 h-96 bg-gradient-to-tl from-[#00ffff]/10 to-transparent rounded-full blur-3xl"></div>
        </div>

        {/* Music Control Button */}
        <button
          onClick={toggleMute}
          className="absolute top-6 right-6 z-20 bg-[#ff0055] hover:bg-[#ff0055]/90 text-white p-3 rounded-full neon-glow transition-all"
          title={isMuted ? "تشغيل الصوت" : "إيقاف الصوت"}
        >
          {isMuted ? <VolumeX className="w-5 h-5" /> : <Volume2 className="w-5 h-5" />}
        </button>

        {/* Login Card with Enhanced Parallax and LED Border */}
        <Card
          ref={cardRef}
          className="w-full max-w-md relative z-10 bg-card led-border transition-transform duration-75"
          style={{
            transform: `perspective(1200px) rotateX(${mousePos.y * 0.8}deg) rotateY(${mousePos.x * -0.8}deg) translateZ(30px) scale(1.02)`,
          }}
        >
          <CardHeader className="space-y-2">
            <div className="text-center">
              <div className="text-4xl font-bold text-[#ff0055] mb-2 glitch-text animated-title" style={{ fontFamily: "Orbitron, monospace" }}>
                VST
              </div>
              <CardTitle className="text-2xl">Cheats</CardTitle>
              <CardDescription className="text-[#00ffff] mt-2">منصة الألعاب المتقدمة</CardDescription>
              <CardDescription className="text-white/60 text-xs mt-3">Advanced Gaming Platform</CardDescription>
            </div>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleLogin} className="space-y-4">
              <div className="space-y-2">
                <label className="text-sm font-medium">البريد الإلكتروني</label>
                <Input
                  type="email"
                  placeholder="your@email.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="bg-background border-[#2a3050] focus:border-[#ff0055] focus:ring-[#ff0055]"
                  required
                />
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium">كلمة المرور</label>
                <Input
                  type="password"
                  placeholder="••••••••"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="bg-background border-[#2a3050] focus:border-[#ff0055] focus:ring-[#ff0055]"
                  required
                />
              </div>
              <Button
                type="submit"
                className="w-full bg-[#ff0055] hover:bg-[#ff0055]/90 text-white font-bold neon-glow"
              >
                دخول / تسجيل
              </Button>
            </form>
            <p className="text-xs text-muted-foreground text-center mt-4">
              جميع الخدمات تعليمية وقانونية فقط
            </p>
            <p className="text-xs text-white/40 text-center mt-2">
              All services are educational and legal only
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background text-foreground scanline">
      {/* Background Music */}
      <audio
        ref={audioRef}
        src="https://d2xsxph8kpxj0f.cloudfront.net/310419663031979111/Fs5wiWQggZNfgF3JSoAX3t/TIKITIKI(Slowed)[EXTENDED]_a21d108f.mp3"
        loop
        playsInline
      />

      {/* Network Particles */}
      <div className="network-particles">
        <div className="particle"></div>
        <div className="particle"></div>
        <div className="particle"></div>
        <div className="particle"></div>
        <div className="particle"></div>
        <div className="particle"></div>
        <div className="particle"></div>
        <div className="particle"></div>
      </div>

      {/* Spider Web Animation */}
      <div className="spider-web">
        <div className="spider-web-line"></div>
        <div className="spider-web-line"></div>
        <div className="spider-web-line"></div>
        <div className="spider-web-line"></div>
        <div className="spider-web-line"></div>
      </div>

      {/* Header */}
      <header className="sticky top-0 z-50 bg-card/80 backdrop-blur-md border-b border-[#ff0055]/30 neon-border">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="text-3xl font-bold text-[#ff0055] glitch-text animated-title" style={{ fontFamily: "Orbitron, monospace" }}>
              VST
            </div>
            <span className="text-xl font-semibold text-[#00ffff]">Cheats</span>
          </div>
          <nav className="hidden md:flex items-center gap-6">
            <a href="#subscriptions" className="text-sm font-medium hover:text-[#ff0055] transition-colors">
              الاشتراكات
            </a>
            <a href="#tutorials" className="text-sm font-medium hover:text-[#ff0055] transition-colors">
              الشروحات
            </a>
            <a href="#gallery" className="text-sm font-medium hover:text-[#ff0055] transition-colors">
              المعرض
            </a>
            <button
              onClick={() => scrollToSection("contact")}
              className="text-sm font-medium hover:text-[#ff0055] transition-colors"
            >
              تواصل معنا
            </button>
            <button
              onClick={toggleMute}
              className="text-sm font-medium hover:text-[#ff0055] transition-colors flex items-center gap-2"
            >
              {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
            </button>
            <Button
              onClick={handleLogout}
              variant="outline"
              size="sm"
              className="border-[#ff0055] text-[#ff0055] hover:bg-[#ff0055]/10"
            >
              خروج
            </Button>
          </nav>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative py-20 md:py-32 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-background via-[#0a0e27]/80 to-background"></div>

        <div className="container mx-auto px-4 relative z-10">
          <div className="max-w-2xl">
            <h1 className="text-5xl md:text-7xl font-bold mb-6 text-[#ff0055] glitch-text animated-title" style={{ fontFamily: "Orbitron, monospace" }}>
              The Best
            </h1>
            <h2 className="text-4xl md:text-6xl font-bold mb-6 text-[#00ffff]" style={{ fontFamily: "Orbitron, monospace" }}>
              Garena Free Fire Panel
            </h2>
            <p className="text-xl md:text-2xl text-white mb-8 font-light">
              اكتشف أفضل الأدوات والشروحات لتحسين مستواك في الألعاب
            </p>
            <div className="flex gap-4">
              <Button
                onClick={() => scrollToSection("subscriptions")}
                size="lg"
                className="bg-[#ff0055] hover:bg-[#ff0055]/90 text-white font-bold neon-glow pulse-glow"
              >
                ابدأ الآن
              </Button>
              <Button
                onClick={() => scrollToSection("gallery")}
                size="lg"
                variant="outline"
                className="border-[#00ffff] text-[#00ffff] hover:bg-[#00ffff]/10 font-bold"
              >
                تعرف أكثر
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Subscriptions Section */}
      <section id="subscriptions" className="py-20 border-t border-[#ff0055]/30">
        <div className="container mx-auto px-4">
          <h2 className="text-4xl font-bold text-center mb-4 text-[#ff0055]" style={{ fontFamily: "Orbitron, monospace" }}>
            الاشتراكات
          </h2>
          <p className="text-center text-muted-foreground mb-12 text-[#00ffff]">
            اختر الخطة المناسبة لك
          </p>

          <div className="grid md:grid-cols-3 gap-8 mb-8">
            {[
              { title: "اشتراك أسبوع", price: "10", period: "دولار" },
              { title: "اشتراك شهر", price: "20", period: "دولار" },
              { title: "اشتراك شهرين", price: "30", period: "دولار", featured: true },
            ].map((plan, idx) => (
              <Card
                key={idx}
                className={`relative overflow-hidden transition-all ${
                  plan.featured
                    ? "neon-glow pulse-glow border-2 border-[#ff0055] scale-105"
                    : "neon-border hover:neon-glow"
                }`}
              >
                {plan.featured && (
                  <div className="absolute top-0 right-0 bg-[#ff0055] text-white px-4 py-1 text-xs font-bold">
                    الأفضل
                  </div>
                )}
                <div
                  className="absolute inset-0 bg-gradient-to-br from-[#ff0055]/5 to-[#00ffff]/5 pointer-events-none"
                ></div>
                <CardHeader className="relative">
                  <CardTitle className="text-2xl">{plan.title}</CardTitle>
                </CardHeader>
                <CardContent className="relative space-y-6">
                  <div className="text-center">
                    <div className="text-5xl font-bold text-[#ff0055]" style={{ fontFamily: "Orbitron, monospace" }}>
                      {plan.price}
                    </div>
                    <div className="text-[#00ffff] text-sm mt-2">{plan.period}</div>
                  </div>
                  <ul className="space-y-3 text-sm">
                    <li className="flex items-center gap-2">
                      <Zap className="w-4 h-4 text-[#ff0055]" />
                      <span>وصول كامل للمحتوى</span>
                    </li>
                    <li className="flex items-center gap-2">
                      <Zap className="w-4 h-4 text-[#ff0055]" />
                      <span>دعم أولوي</span>
                    </li>
                    <li className="flex items-center gap-2">
                      <Zap className="w-4 h-4 text-[#ff0055]" />
                      <span>تحديثات منتظمة</span>
                    </li>
                  </ul>
                  <Button
                    onClick={() => handleSubscribe(plan.title)}
                    className="w-full bg-[#ff0055] hover:bg-[#ff0055]/90 text-white font-bold neon-glow"
                  >
                    اشترك الآن
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>

          <div className="bg-card border-2 border-[#00ffff]/50 rounded-lg p-6 text-center neon-glow">
            <p className="text-[#ff0055] font-bold">
              ⚠️ أول دفعة 50 دولار، ثم يمكنك شراء الاشتراكات
            </p>
          </div>
        </div>
      </section>

      {/* Tutorials Section */}
      <section id="tutorials" className="py-20 border-t border-[#ff0055]/30 bg-card/30">
        <div className="container mx-auto px-4">
          <h2 className="text-4xl font-bold text-center mb-4 text-[#ff0055]" style={{ fontFamily: "Orbitron, monospace" }}>
            الشروحات
          </h2>
          <p className="text-center text-muted-foreground mb-12 text-[#00ffff]">
            تعلم من أفضل الخبراء
          </p>

          {/* Customer Counter */}
          <div className="flex justify-center mb-12">
            <Card className="neon-border bg-card/50 px-8 py-6">
              <div className="flex items-center justify-center gap-4">
                <Users className="w-8 h-8 text-[#ff0055]" />
                <div className="text-center">
                  <div className="text-4xl font-bold text-[#ff0055]" style={{ fontFamily: "Orbitron, monospace" }}>
                    5000+
                  </div>
                  <p className="text-[#00ffff] text-sm mt-1">عميل مشترك</p>
                </div>
              </div>
            </Card>
          </div>

          <div className="grid md:grid-cols-3 gap-6">
            {[
              {
                icon: Play,
                title: "شرح استخدام الأدوات",
                desc: "بطريقة قانونية وآمنة",
              },
              {
                icon: Zap,
                title: "نصائح تحسين الأداء",
                desc: "في اللعبة بشكل احترافي",
              },
              {
                icon: MessageSquare,
                title: "دروس فيديو تعليمية",
                desc: "شاملة وسهلة الفهم",
              },
            ].map((tutorial, idx) => {
              const Icon = tutorial.icon;
              return (
                <Card key={idx} className="neon-border hover:neon-glow transition-all">
                  <CardHeader>
                    <div className="w-12 h-12 rounded-lg bg-[#ff0055]/20 flex items-center justify-center mb-4">
                      <Icon className="w-6 h-6 text-[#ff0055]" />
                    </div>
                    <CardTitle>{tutorial.title}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-muted-foreground">{tutorial.desc}</p>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>
      </section>

      {/* Gallery Section - MP4 Video */}
      <section id="gallery" className="py-20 border-t border-[#ff0055]/30">
        <div className="container mx-auto px-4">
          <h2 className="text-4xl font-bold text-center mb-4 text-[#ff0055]" style={{ fontFamily: "Orbitron, monospace" }}>
            المعرض
          </h2>
          <p className="text-center text-muted-foreground mb-12 text-[#00ffff]">
            استعرض أفضل المحتوى
          </p>

          <div className="flex justify-center">
            <Card className="w-full max-w-2xl neon-border hover:neon-glow transition-all overflow-hidden">
              <div className="aspect-video bg-gradient-to-br from-[#ff0055]/20 to-[#00ffff]/20 flex items-center justify-center relative">
                <video
                  width="100%"
                  height="100%"
                  controls
                  className="w-full h-full object-cover"
                  style={{ maxWidth: "100%", height: "600px" }}
                >
                  <source
                    src="https://d2xsxph8kpxj0f.cloudfront.net/310419663031979111/Fs5wiWQggZNfgF3JSoAX3t/Download_938e0ec9.mp4"
                    type="video/mp4"
                  />
                  متصفحك لا يدعم تشغيل الفيديو
                </video>
              </div>
            </Card>
          </div>
        </div>
      </section>

      {/* Payment Methods Section */}
      <section id="payment" className="py-20 border-t border-[#ff0055]/30 bg-card/30">
        <div className="container mx-auto px-4">
          <h2 className="text-4xl font-bold text-center mb-4 text-[#ff0055]" style={{ fontFamily: "Orbitron, monospace" }}>
            طرق الدفع المتوفرة
          </h2>
          <p className="text-center text-muted-foreground mb-12 text-[#00ffff]">
            اختر طريقة الدفع المناسبة لك
          </p>

          <div className="grid md:grid-cols-3 lg:grid-cols-6 gap-4">
            {[
              { name: "MASTER CARD", icon: "💳" },
              { name: "VISA", icon: "💳" },
              { name: "PAYPAL", icon: "🅿️" },
              { name: "BINANCE", icon: "₿" },
              { name: "FF DIAMOND", icon: "💎" },
              { name: "FF ACCOUNT", icon: "👤" },
            ].map((method, idx) => (
              <Card
                key={idx}
                className="neon-border hover:neon-glow transition-all cursor-pointer group"
              >
                <CardContent className="pt-6 text-center">
                  <div className="text-4xl mb-3 group-hover:scale-110 transition-transform">
                    {method.icon}
                  </div>
                  <p className="font-bold text-sm text-[#ff0055]">{method.name}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Section - Improved */}
      <section id="contact" className="py-20 border-t border-[#ff0055]/30">
        <div className="container mx-auto px-4">
          <h2 className="text-4xl font-bold text-center mb-4 text-[#ff0055]" style={{ fontFamily: "Orbitron, monospace" }}>
            تواصل معنا
          </h2>
          <p className="text-center text-muted-foreground mb-12 text-[#00ffff]">
            لديك سؤال؟ نحن هنا للمساعدة
          </p>

          <div className="flex justify-center">
            <Button
              onClick={handleContact}
              size="lg"
              className="bg-[#ff0055] hover:bg-[#ff0055]/90 text-white font-bold neon-glow pulse-glow px-12 py-8 text-lg flex items-center justify-center gap-3"
            >
              <ExternalLink className="w-6 h-6" />
              تواصل معنا الآن
            </Button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-[#ff0055]/30 bg-card/50 py-12">
        <div className="container mx-auto px-4 text-center space-y-4">
          <p className="text-sm text-muted-foreground mb-2">© 2026 VST Cheats</p>
          <p className="text-xs text-[#00ffff]">جميع الخدمات تعليمية وقانونية فقط</p>
          <p className="text-xs text-white/40">All services are educational and legal only</p>
          <div className="border-t border-[#ff0055]/20 pt-4 mt-4">
            <p className="text-xs text-[#ff0055] font-semibold">
              تم تطوير الموقع بواسطة المطور Brazil
            </p>
            <p className="text-xs text-white/50 mt-1">
              Developed by Developer Brazil
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
